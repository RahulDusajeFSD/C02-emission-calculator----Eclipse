/* This class accounts for the front page of the application where the a choice is given-- either to calculate or to exit--
 * The methods are called of service class to maintain code readibility and the work flow goes to Service class from here 
 * */

package com.sap.task1.ui;

import java.util.Scanner;

import com.sap.task1.service.Service;

public class UI {
	
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		Service service= new Service();
		
		int option=0;
		
		
		while(option!=2)
		{
			System.out.println("Press 1 to calculate C02-emission");
			System.out.println("Press 2 to exit");
			System.out.println("Enter your choice:");
			option=sc.nextInt();
			sc.nextLine();
			
			switch(option)
			{
			case 1: System.out.println("Enter Transportation method");
					String method=sc.nextLine();
					if(!service.ifExists(method))
					{
						System.out.println("ERROR---Please enter correct Transportation mode---");
					}
					else
					{
					System.out.println("Enter Distance");
					Double dVal=sc.nextDouble();
					System.out.println("Enter Distance unit");
					String dUnit=sc.next();
					if(!service.ifExistsUnit(dUnit))
					{
						System.out.println("ERROR---Please enter correct Distance Unit---");
					}
					else
					{
					double res= service.compute(method,dVal,dUnit);
				
					System.out.println("Your trip caused "+res+"kg "+"of C02-equivalent");
					}
					}
					
					System.out.println();
					
					
					break;
			
			case 2: System.exit(0);
					
				
			}
		}

	}

}
