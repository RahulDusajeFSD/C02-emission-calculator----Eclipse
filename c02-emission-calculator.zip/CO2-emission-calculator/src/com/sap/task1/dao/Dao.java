/* This Class accounts for the actual Business logic implementation-- 
 * Here, the Travel method, unit and computation of C02-emmission method is implemented
 * */

package com.sap.task1.dao;


import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;

public class Dao {

	
	Map<String,Integer> map = new HashMap<>();
	
	public void fillData()
	{
		map.put("small-diesel-car",142);
		map.put("small-petrol-car",152);
		map.put("small-plugin-hybrid-car",73);
		map.put("small-electric-car",50);
		map.put("medium-diesel-car",171);
		map.put("medium-petrol-car",192);
		map.put("medium-plugin-hybrid-car",110);
		map.put("medium-electric-car",58);
		map.put("large-diesel-car",209);
		map.put("large-petrol-car",282);
		map.put("large-plugin-hybrid-car",126);
		map.put("large-electric-car",73);
		map.put("bus",27);
		map.put("train",6);
		
	}
	
	
	// To check if the transportation method entered is correct or not
	public boolean ifExists(String method) {
		
		if(!map.containsKey(method))
			return false;
		
		return true;
		
		
	}
	
public boolean ifExistsUnit(String dUnit) {
	
	if(dUnit.equals("km")||dUnit.equals("KM")||dUnit.equals("M") ||dUnit.equals("m"))
	return true;
	
	return false;
}
		
		
		


// This method hold the calculation part
	public double compute(String method, Double dVal, String dUnit) {
		int val=0;
		for(Map.Entry<String,Integer> entry:map.entrySet())
		{
			if(entry.getKey().equals(method))
			{
				val=entry.getValue();
			}
		}
		
		    DecimalFormat f = new DecimalFormat("##.0"); // To round off values to 1 decimal place
		
			return Double.parseDouble(f.format(dVal*val/1000));
		

		
		
		
	}

	
	
}
