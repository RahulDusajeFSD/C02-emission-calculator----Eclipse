/*Bean class accounts for the Object creation every time the user presses 1, gets the details
 * and the data values are passed through parameterized constructor(object is created).
 *  */

package com.sap.task1.bean;

public class Bean {

	String method;
	Double distance;
	String unit;
	
//	
//	@Override
//	public String toString() {
//		return "Bean [method=" + method + ", distance=" + distance + ", unit=" + unit + "]";
//	}
	public Bean(String method, Double distance, String unit) {
		super();
		this.method = method;
		this.distance = distance;
		this.unit = unit;
	}
	public Bean() {
		
	}
	
	
	
	
}
