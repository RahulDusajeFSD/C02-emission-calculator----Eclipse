/* This class accounts for the intermediate between ui and DAO class where actual business logic is implemented
 * *From here the methods of DAO class are called.
 * */
package com.sap.task1.service;

import com.sap.task1.dao.Dao;

public class Service {

	Dao d= new Dao();
	public boolean ifExists(String method)
	{
		d.fillData();
		return d.ifExists(method);
	}
	public Double compute(String method, Double dVal, String dUnit) {
		
		return d.compute(method,dVal,dUnit);
		
	}
	public boolean ifExistsUnit(String dUnit) {
		return d.ifExistsUnit(dUnit);
	}
}
